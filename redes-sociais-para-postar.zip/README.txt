📱 POSTS PRONTOS PARA REDES SOCIAIS — Evolua

Este pacote contém 2 campanhas completas geradas pelo pipeline de conteúdo automatizado da Evolua.

═══════════════════════════════════════════
CAMANHA 1: Gestão de Consultório para Fonoaudiólogas
═══════════════════════════════════════════
📌 Tema: Guia Prático de Gestão (formalização, precificação, marketing, finanças, LGPD, automação)
📅 Publicação sugerida: Segunda-feira

Inclui:
  linkedin.txt   → Post para LinkedIn (texto + hashtags)
  instagram.txt  → Carrossel 5 slides + legenda + hashtags
  threads.txt    → Thread de 6 tweets
  x-twitter.txt  → Post para X/Twitter (280 chars)

═══════════════════════════════════════════
CAMANHA 2: Dicas para Fonoaudiólogas no Instagram
═══════════════════════════════════════════
📌 Tema: Marketing ético no Instagram (CFFa 600/2021, funil, pilares de conteúdo)
📅 Publicação sugerida: Quarta-feira

Inclui:
  linkedin.txt   → Post para LinkedIn (texto + hashtags)
  instagram.txt  → Carrossel 5 slides + legenda + hashtags
  threads.txt    → Thread de 5 tweets
  x-twitter.txt  → Post para X/Twitter (280 chars)

═══════════════════════════════════════════
INSTRUÇÕES DE POSTAGEM
═══════════════════════════════════════════

📸 Instagram:
- Criar artes dos slides como imagens (Canva/Photoshop)
- Colar legenda completa no campo de legenda
- Hashtags no final da legenda (não nos comentários)

💼 LinkedIn:
- Postar o texto como artigo ou post normal
- Se for artigo, expandir com mais detalhes do blog

🧵 Threads:
- Cada tweet numerado = 1 post separado
- Postar em sequência, numerando 1/N, 2/N...

🐦 X/Twitter:
- Postar como tweet único
- Pode adicionar imagem de apoio

📌 Blog (para referência):
- Post completo: useevolua.com.br/blog

🔗 Links para agendamento:
- Teste grátis Evolua 14 dias: evolua.app
- Blog: evolua.app/blog

Feito por Evolua — CRM inteligente para fonoaudiólogas
